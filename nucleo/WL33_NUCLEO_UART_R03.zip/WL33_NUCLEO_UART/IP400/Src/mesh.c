/*---------------------------------------------------------------------------
	Project:	    WL33_NUCLEO_UART

	File Name:	    mesh.c

	Author:		    MartinA

	Description:	This code builds and lists the mesh status

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

				    Copyright (c) Alberta Digital Radio Communications Society
				    All rights reserved.

	Revision History:

---------------------------------------------------------------------------*/
#include <cmsis_os2.h>
#include <sys/queue.h>
#include <stdint.h>
#include <FreeRTOS.h>
#include <task.h>
#include <malloc.h>
#include <string.h>
#include <stdio.h>

#include "tasks.h"
#include "frame.h"
#include "usart.h"
#include "dataq.h"
#include "setup.h"
#include "tod.h"

#define	EXPIRY_TIME		100			// seconds since last heard

char *FSKSpeeds[] = {
		"FSK 1200 ",
		"FSK 9600 ",
		"FSK_56K ",
		"FSK_100K ",
		"FSK_200K ",
		"FSK_300K ",
		"FSK_400K ",
		"FSK_600K "
};

// mesh entry struct
struct mesh_entry_t {
	struct mesh_entry_t	*q_forw;		// forward pointer
	struct mesh_entry_t	*q_back;		// backward pointer
	IP400_CALL			encCall;		// encoded callsign
	SETUP_FLAGS			capabilities;	// capabilities
	TIMEOFDAY			lastHeard;		// last heard
};

struct mesh_entry_t		meshHead;	// head of mesh chain
int nMeshEntries = 0;

// forward refs in this module
struct mesh_entry_t *findCall(IP400_CALL *call);

// task initialization
void Mesh_Task_Init(void)
{
	meshHead.q_forw = &meshHead;
	meshHead.q_back = &meshHead;
}

// process a beacon packet: if we don't have it, enter it
// otherwise update the last time heard
void Mesh_ProcessBeacon(void *frame)
{
	IP400_CALL *p = (IP400_CALL *)frame;
	struct mesh_entry_t *newEntry;

	TIMEOFDAY current;
	getTOD(&current);

	union {
		SETUP_FLAGS flags;
		uint8_t bucketoflags[sizeof(SETUP_FLAGS)];
	} flagBytes;

	// see if we already know about it
	// if so, just update last heard
	if((newEntry = findCall(p)) != NULL)	{
		newEntry->lastHeard.Hours = current.Hours;
		newEntry->lastHeard.Minutes = current.Minutes;
		newEntry->lastHeard.Seconds = current.Seconds;
		return;
	}

	// skip over header to data part of the frame
	uint8_t *c = (uint8_t *)frame + 2*sizeof(IP_400_CALL_SIZE);
	c += IP_400_FLAG_SIZE;		// flags
	c += 3*sizeof(uint16_t);	// data length

	// now at capability flags
	memcpy(flagBytes.bucketoflags, c, sizeof(SETUP_FLAGS));

	// create a new entry
	if((newEntry = (struct mesh_entry_t *)malloc(sizeof(struct mesh_entry_t))) == NULL) {
		return;
	}

	// grab call and capabilities
	newEntry->encCall = *p;

	newEntry->capabilities = flagBytes.flags;
	newEntry->lastHeard.Hours = current.Hours;
	newEntry->lastHeard.Minutes = current.Minutes;
	newEntry->lastHeard.Seconds = current.Seconds;

	// insert this at the end of the queue
	insque((struct qelem *)newEntry, (struct qelem *)meshHead.q_back);
	nMeshEntries++;
}

// find a callsign in the list
struct mesh_entry_t *findCall(IP400_CALL *call)
{
	struct mesh_entry_t *elem = meshHead.q_forw;

	for(int i=0;i<nMeshEntries;i++)	{
		if(elem->encCall.callbytes.encoded == call->callbytes.encoded)
			return elem;
		elem = elem->q_forw;
	}
	return NULL;
}

char capabilties[50];
// return the capabilites of a node
char *GetCapabilities(SETUP_FLAGS cap)
{
	if(cap.fsk)		{
		sprintf(capabilties, "%s", FSKSpeeds[cap.rate]);
	}
	if(cap.ofdm)	{
		strcat(capabilties, "OFDM ");
	}
	if(cap.aredn)	{
		strcat(capabilties, "AREDN ");
	}
	return capabilties;
}

// list the mesh status: walk the mesh entries
void Mesh_ListStatus(void)
{
	USART_Print_string("Stations Heard: %d\r\n", nMeshEntries);
	if(nMeshEntries == 0)
		return;

	// process the list
	struct mesh_entry_t *elem = meshHead.q_forw;
	char decodedCall[20];
	uint16_t port;

	for(int i=0;i<nMeshEntries;i++)	{
		callDecode(&elem->encCall, decodedCall, &port);
		USART_Print_string("%s(%d)\t%s\t%02d:%02d:%02d\r\n", decodedCall, port, GetCapabilities(elem->capabilities),
				elem->lastHeard.Hours, elem->lastHeard.Minutes, elem->lastHeard.Seconds);
		elem = elem->q_forw;
	}
	USART_Print_string("\r\n\n");
}
