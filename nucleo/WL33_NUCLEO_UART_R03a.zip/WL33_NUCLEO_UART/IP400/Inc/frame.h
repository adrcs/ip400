/*---------------------------------------------------------------------------
	Project:	      WL33_NUCLEO_UART

	Module:		      <module description here>

	File Name:	      frame.h

	Date Created:	  Jan 8, 2025

	Author:			  MartinA

	Description:      <what it does>

					  Copyright © 2024-25, Alberta Digital Radio Communications Society,
					  All rights reserved


	Revision History:

---------------------------------------------------------------------------*/

#ifndef FRAME_H_
#define FRAME_H_

#include <stdint.h>
#include "types.h"

// frame defines
#define	N_CALL				4			// octets in the excess-40 compressed callsign
#define	MAX_CALL			6			// max callsign size
#define	EXT_CALL			4*MAX_CALL	// extended call sign field
#define	PAYLOAD_MIN			56			// min octets in payload
#define PAYLOAD_MAX			1053		// max octets in payload
#define	MAX_CALL_BUFFER		20			// max buffering for callsign in payload
#define	N_FEC				4			// number of bytes in the FEC
#define	BROADCAST_ADDR		0xFF		// broadcast address

// header flags
typedef struct frame_flags_t {
	unsigned hop_count: 	4;		// hop count
	unsigned coding:		4;		// coding method
	unsigned compression: 	2;		// compression method
	unsigned unused:		1;		// unused
	unsigned srcExt:		1;		// source call is extended
	unsigned destExt:		1;		// dest call is extended
	unsigned command:		1;		// command packet
	unsigned noconnect:		1;		// connectionless
	unsigned repeat:		1;		// repeat flag
} IP400_FLAGS;

// callsign field
typedef	struct callsign_t	{
	union {
		uint8_t		bytes[N_CALL];	// compressed callsign
		uint32_t	encoded;
	} callbytes;
	uint16_t	port;				// port information
} IP400_CALL;

// complete frame
typedef struct ip400_frame_t	{
	IP400_CALL	source;				// source call sign
	IP400_CALL	dest;				// destination call sign
	union {
		IP400_FLAGS	flags;			// flag bit field
		uint16_t	allflags;		// all flags
	} flagfld;
	void 		*buf;				// data to send
	uint16_t	length;				// data length
} IP400_FRAME;

// min/max payload sizes
#define	IP_400_CALL_SIZE	N_CALL + sizeof(uint16_t)
#define	IP_400_FLAG_SIZE	sizeof(uint16_t)
#define	IP_400_HDR_SIZE		(2*IP_400_CALL_SIZE + IP_400_FLAG_SIZE)
#define	IP_400_LEN_SIZE		sizeof(uint16_t)
#define	MIN_FRAME_SIZE		sizeof(IP400_FRAME) + PAYLOAD_MIN + N_FEC
#define MAX_FRAME_SIZE		MIN_FRAME_SIZE - PAYLOAD_MIN + PAYLOAD_MAX
// packet types
enum {
		UTF8_TEXT_PACKET=0,		// Text packet
		COMPRESSED_AUDIO,		// compressed audio packet
		COMPREESSD_VIDEO,		// compressed video packet
		DATA_PACKET,			// data packet
		PING_PACKET,			// ping packet
		IP_ENCAPSULATED,		// IP encapsulated packet
		AX_25_PACKET,			// AX.25 encapsulated packet
		RFC4733_DTMF,			// DTMF packet
		DMR_FRAME,				// DMR Frame
		DSTAR_FRAME,			// Dstar Frame
		P25_FRAME,				// TIA project 25
		NXDN_FRAME,				// NXDN
		M17_FRAME,				// M17
		TBD_1,
		TBD_2,
		LOCAL_COMMAND			// local command frame
};

// audio compression types
enum {
		AUDIO_RAW,				// raw 16-bit PCM
		AUDIO_ULAW,				// mu law compression
		AUDIO_CODEC2,			// codec 2 encoded
		AUDIO_AMBE				// AMBE encoded
};

// H.246 Video compression
enum {
		H264_240_180_24,		// H.264: 240x180, 24FPS
		H264_320_240_24,		// H.264: 320x240, 24FPS
		H264_480_360_12,		// H.264: 480x360, 12FPS
		H264_640_480_6			// H.264: 640x480, 6FPS
};

// callsign fields
enum	{
	SRC_CALLSIGN=0,				// dest for encode is source callsign
	DEST_CALLSIGN				// dest for encode is dest callsign
};

// frame stats
typedef struct frame_stats_t {
	uint32_t		TxFrameCnt;					// transmit frame count
	uint32_t		RxFrameCnt;					// good receive frame count
	uint32_t		CRCErrors;					// CRC Errors
	uint32_t		TimeOuts;					// Timeouts
} FRAME_STATS;

// packet types
#define	ICMP_TYPE		1		// control message type
#define	ENC_IP_TYPE		4		// encapsulated IP
#define	AUDIO_TYPE		11		// audio packets
#define	TEXT_TYPE		17		// port for text chat (UDP)
#define	VIDEO_TYPE		75		// H.264 video
#define	ENC_AX25_TYPE	93		// encapsulated AX25 packets

// references
uint8_t callEncode(char *callsign, uint16_t port, IP400_FRAME *frame, uint8_t dest, uint8_t offset);
BOOL callDecode(IP400_CALL *encCall, char *callsign, uint16_t *port);

// frame senders
BOOL SendTextFrame(char *srcCall, uint16_t srcPort, char *destCall, uint16_t dstPort, char *buf, uint16_t length, BOOL repeat);
void SendBeaconFrame(char *srcCall, uint8_t *payload, int bcnlen);

//
BOOL EnqueChatFrame(void *Frame, int length);	// queue a chat frame
FRAME_STATS *GetFrameStats(void);				// return the frame stats


#endif /* FRAME_H_ */
