/*---------------------------------------------------------------------------
	Project:	    WL33_NUCLEO_UART

	File Name:	    menu.c

	Author:		    MartinA

	Description:	Menu handler

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

				    Copyright (c) Alberta Digital Radio Communications Society
				    All rights reserved.

	Revision History:

---------------------------------------------------------------------------*/
#include <string.h>

#include "types.h"
#include "usart.h"
#include "streambuffer.h"
#include "setup.h"
#include "tasks.h"

uint8_t menuState;		// menu state
enum {
	MENU_OFF,			// off
	MENU_SHOWING,		// showing the menu
	MENU_SELECTING,		// getting a selection
	MENU_SELECTED,		// item has been selected
	MENU_PAUSED			// pausing a while...
};

// DEC VT100 Escape sequences
#define ASCII_TAB		0x09
#define ASCII_RET		0x0D
#define	ASCII_ESC		0x1B			// escape char
#define	DEC_LEADIN		'['				// lead-in character
#define	MAX_SEQ			6				// max sequence length

enum {
	CONTROL_CLEAR=0,			// clear screen
	CONTROL_HOME,				// cursor home
	CONTROL_DOUBLE_TOP,			// double wide and height (top)
	CONTROL_DOUBLE_BOTTOM,		// double wide and height (bottom)
	CONTROL_SINGLE,				// single wide and height
	NCONTROL_CODES				// number of conrol codes
};
struct controlCodes_t	{
	char sequence[MAX_SEQ];		// sequence
	uint8_t	len;				// length
} controlCodes[NCONTROL_CODES] = {
		{{ASCII_ESC, DEC_LEADIN, '2', 'J'}, 4},
		{{ASCII_ESC, DEC_LEADIN, 'H'},      3},
		{{ASCII_ESC, '#', '3'},    		    3},
		{{ASCII_ESC, '#', '4'},    		    3},
		{{ASCII_ESC, '#', '5'},    		    3},
};

// main menu
char *menuTitle	= 	"      IP400 menu\r\n";
char *menuLine1	=	"Show setup\r\n";
char *menuLine2 =	"Mesh Status\r\n";
char *menuLine3 =	"Chat Mode\r\n";
char *menuLine4 = 	"Dump Frame stats\r\n\n";
char *menuLine5	=	"Exit\r\n\n";
char *selectItem = 	"Select an item->";
char *whatItem = 	"??Try again->";
char *menuSpacer =  "\r\n\n";
char *pauseString = "Hit enter to continue->";

static char menu[100];			// Buffer for file items

int sel_item = 0;				// selected item

#define	NO_ITEM		-1			// no item selected
#define N_MENULINES	5			// number of lines in the menu

// forward refs in this module
void printMenu(void);		// print the menu
int getMenuItem(void);		// get a menu item
void sendControlCode(uint8_t code);
BOOL pause(void);
void Print_Frame_stats(FRAME_STATS *stats);

/*
 * menu processors
 * handle the various menu options
 * return TRUE if done, else FALSE
 */
BOOL printSetup(void)
{
	printSetupStruct();
	return TRUE;
}

// list mesh status
BOOL listMesh(void)
{
	Mesh_ListStatus();
	return TRUE;
}

// enter chat mode
BOOL chatMode(void)
{
	return(Chat_Task_exec());
}

// dump the rx stats
BOOL showstats(void)
{
	Print_Frame_stats(GetFrameStats());
	return TRUE;
}

//
BOOL exitMenu(void)
{
	menuState = MENU_OFF;
	return TRUE;;
}

// menu items
struct menuItems_t {
		char	**menuLine;
		char	selChar;
		BOOL	(*func)(void);
} menuItems[N_MENULINES] = {
		{ &menuLine1, 'A', printSetup },
		{ &menuLine2, 'B', listMesh },
		{ &menuLine3, 'C', chatMode },
		{ &menuLine4, 'D', showstats },
		{ &menuLine5, 'X', exitMenu }
};


// menu (main) task
void Menu_Task_Init(void)
{
	// start off with the menu showing
	menuState = MENU_SHOWING;
}

// send a control code
void sendControlCode(uint8_t code)
{
	USART_Send_String(controlCodes[code].sequence, controlCodes[code].len);
}

// send a control code
void sendTextString(char *string)
{
	strcpy(menu, string);
	USART_Send_String(menu, strlen(string));
}

// process our time slot
void Menu_Task_Exec(void)
{
	int nBytesinBuff = 0;
	char c;

	switch(menuState)	{

	// if there is a return in the console buffer,
	// bring  up the menu
	case MENU_OFF:
		if((nBytesinBuff=databuffer_bytesInBuffer()) == 0)
			return;
		for(int i=0;i<nBytesinBuff;i++)
			if((c=databuffer_get(0)) == ASCII_RET)
				menuState = MENU_SHOWING;
		return;

	case MENU_SHOWING:
		printMenu();
		menuState = MENU_SELECTING;
		return;

	case MENU_SELECTING:
		if((sel_item=getMenuItem()) == NO_ITEM)
			return;
		menuState = MENU_SELECTED;
		break;

	case MENU_SELECTED:
		if((*menuItems[sel_item].func)())	{
			sendTextString(pauseString);
			menuState = MENU_PAUSED;
		}
		break;

	case MENU_PAUSED:
		if(pause())
			menuState = MENU_SHOWING;
		break;

	}
}

// print the main menu
void printMenu(void)
{

	// title
	sendControlCode(CONTROL_CLEAR);
	sendControlCode(CONTROL_HOME);

	sendControlCode(CONTROL_DOUBLE_TOP);
	sendTextString(menuTitle);
	sendControlCode(CONTROL_DOUBLE_BOTTOM);
	sendTextString(menuTitle);
	sendControlCode(CONTROL_SINGLE);
	sendTextString(menuSpacer);

	// lines
	for(int i=0;i<N_MENULINES;i++)	{
		menu[0] = menuItems[i].selChar;
		strcpy(&menu[1], ") ");
		strcat(menu, *menuItems[i].menuLine);
		USART_Send_String(menu, strlen(menu));
	}

	// selection
	sendTextString(selectItem);
}

// get a menu item and dispatch the correct processing routine
int getMenuItem(void)
{
	int nBytesinBuff =0;
	char c;

	if((nBytesinBuff=databuffer_bytesInBuffer()) == 0)
		return NO_ITEM;

	for(int i=0;i<nBytesinBuff;i++)		{
		if((c=databuffer_get(0)) != BUFFER_NO_DATA)	{

			// translate and echo
			c = islower(c) ? toupper(c) : c;
			USART_Send_Char(c);

			// find the correct processing routine
			for(int j=0;j<N_MENULINES;j++)	{
				if(menuItems[j].selChar == c)	{
					sendTextString(menuSpacer);
					return j;
				}
			}
		}
	}
	sendTextString(whatItem);
	return NO_ITEM;
}

BOOL pause(void)
{
	if(databuffer_bytesInBuffer() == 0)
		return FALSE;

	if(databuffer_get(0) == ASCII_RET)
		return TRUE;

	return FALSE;

}

/*
 * Print the frame stats
 */
void Print_Frame_stats(FRAME_STATS *stats)
{
	USART_Print_string("Frame Statistics\r\n\n");

	USART_Print_string("Transmitted frames->%d\r\n", stats->TxFrameCnt);
	USART_Print_string("Good Received frames->%d\r\n", stats->RxFrameCnt);
	USART_Print_string("CRC Errors->%d\r\n", stats->CRCErrors);
	USART_Print_string("Rx Timeouts->%d\r\n\n", stats->TimeOuts);
}
