/*---------------------------------------------------------------------------
	Project:	    WL33_NUCLEO_UART

	File Name:	    setup.c

	Author:		    MartinA

	Description:	Holds and displays the setup data

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

				    Copyright (c) Alberta Digital Radio Communications Society
				    All rights reserved.

	Revision History:

---------------------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "types.h"
#include "setup.h"
#include "usart.h"

// Default Setup Data
union {
	SETUP_DATA	setup_data;
	uint8_t		bytes[sizeof(SETUP_DATA)];
} setup_memory = {
		.setup_data.flags = { 1, 0, 0 , 1, 0, 0 },		// LSB specified first
		.setup_data.stnCall ="NOCALL",
		.setup_data.gridSq = "DO21vd",
		.setup_data.latitude = "51.08",
		.setup_data.longitude = "-114.10",
		.setup_data.radioConfig = &MRSUBG_RadioInitStruct
};

char prtBuf[100];

// enum fields in setup struct
// modulation type
char *modTypes[] = {
		"2FSK",
		"4FSK",
		"2GFSK05",
		"2GFSK1",
		"4GFSK05",
		"4GFSK1",
		"ASK",
		"OOK",
		"POLAR",
		"CW"
};

// PA modes
char *paModes[] = {
		"TX 10dBm Max",
		"HP 14dBm Max",
		"TX_HP 20dBm Max"
};

/*
 * Print the setup struct
 */
void printSetupStruct(void)
{
	// station callsign first
	USART_Print_string("Station Callsign->%s\r\n", setup_memory.setup_data.stnCall);
	if(setup_memory.setup_data.flags.ext)
		USART_Print_string("Extended Callsign->%s\r\n");

	USART_Print_string("Latitude->%s\r\n", setup_memory.setup_data.latitude);
	USART_Print_string("Longitude->%s\r\n", setup_memory.setup_data.longitude);
	USART_Print_string("Grid Square->%s\r\n", setup_memory.setup_data.gridSq);

	USART_Print_string("Capabilities->");
	if(setup_memory.setup_data.flags.fsk)
		USART_Print_string("FSK ");
	if(setup_memory.setup_data.flags.ofdm)
		USART_Print_string("OFDM ");
	if(setup_memory.setup_data.flags.aredn)
		USART_Print_string("AREDN ");
	if(setup_memory.setup_data.flags.repeat)
		USART_Print_string("\r\nRepeat mode on by default\r\n\n");
	else
		USART_Print_string("\r\nRepeat mode off by default\r\n\n");

	// dump the radio init struct
	USART_Print_string("RF Frequency->%d\r\n", setup_memory.setup_data.radioConfig->lFrequencyBase);
	USART_Print_string("Modulation method->%s\r\n", modTypes[setup_memory.setup_data.radioConfig->xModulationSelect]);
	USART_Print_string("Data Rate->%d\r\n", setup_memory.setup_data.radioConfig->lDatarate);
	USART_Print_string("Peak Deviation->%d\r\n", setup_memory.setup_data.radioConfig->lFreqDev);
	USART_Print_string("Bandwidth->%d\r\n", setup_memory.setup_data.radioConfig->lBandwidth);
	USART_Print_string("Output Power->%d dBm\r\n", setup_memory.setup_data.radioConfig->outputPower);
	USART_Print_string("PA Mode->%s\r\n\n\n", paModes[setup_memory.setup_data.radioConfig->PADrvMode]);
}

/*
 * get my callsign
 */
char *GetMyCall(void)
{
	return setup_memory.setup_data.stnCall;
}

/*
 * fill in the data fields in a beacon packet
 */
int SetupBeacon(void *f)
{
	return 0;
}
