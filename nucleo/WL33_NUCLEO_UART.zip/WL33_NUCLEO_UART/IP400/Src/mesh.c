/*---------------------------------------------------------------------------
	Project:	    WL33_NUCLEO_UART

	File Name:	    mesh.c

	Author:		    MartinA

	Description:	This code builds and lists the mesh status

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

				    Copyright (c) Alberta Digital Radio Communications Society
				    All rights reserved.

	Revision History:

---------------------------------------------------------------------------*/
#include <cmsis_os2.h>
#include <sys/queue.h>
#include <stdint.h>
#include <FreeRTOS.h>
#include <task.h>
#include <malloc.h>
#include <string.h>

#include "tasks.h"
#include "frame.h"
#include "usart.h"
#include "dataq.h"

#define	EXPIRY_TIME		100			// seconds since last heard

// mesh entry struct
struct mesh_entry_t {
	struct mesh_entry_t	*q_forw;	// forward pointer
	struct mesh_entry_t	*q_back;	// backward pointer
	uint32_t			encCall;	// encoded callsign
	unsigned long 		lastHeard;	// last heard
	void 				*payload;	// payload buffer
	uint16_t			length;		// length of payload
};

struct mesh_entry_t		meshHead;	// head of mesh chain
int nMeshEntries = 0;

// os stuff
unsigned long startTime;			// time of start
osThreadId_t maintaskHandle;		// handle to main task
TaskStatus_t maintaskStatus;		// status of the main task

// forward refs in this module
struct mesh_entry_t *findCall(uint32_t call);

// task initialization
void Mesh_Task_Init(void *tHandle)
{
	meshHead.q_forw = NULL;
	meshHead.q_back = NULL;

	maintaskHandle = (osThreadId_t) tHandle;
	vTaskGetInfo(maintaskHandle, &maintaskStatus, pdFALSE, eInvalid);

	startTime = maintaskStatus.ulRunTimeCounter;
}

// process a beacon packet: if we don't have it, enter it
// otherwise update the last time heard
void Mesh_ProcessBeacon(void *frame)
{
	IP400_FRAME *p = (IP400_FRAME *)frame;
	struct mesh_entry_t *newEntry;

	// see if we already know about it
	if((newEntry = findCall(p->source.callbytes.encoded)) != NULL)	{
		vTaskGetInfo(maintaskHandle, &maintaskStatus, pdFALSE, eInvalid);
		newEntry->lastHeard = maintaskStatus.ulRunTimeCounter;
		return;
	}

	// create a new entry
	if((newEntry = (struct mesh_entry_t *)malloc(sizeof(struct mesh_entry_t))) == NULL) {
		return;
	}

	uint8_t *bcnStats;
	if((bcnStats = malloc(p->length)) == NULL)	{
		return;
	}
	memcpy(bcnStats, p->buf, p->length);

	vTaskGetInfo(maintaskHandle, &maintaskStatus, pdFALSE, eInvalid);

	newEntry->encCall = p->source.callbytes.encoded;
	memcpy(newEntry->payload,  bcnStats, p->length);
	newEntry->length = p->length;
	newEntry->lastHeard = maintaskStatus.ulRunTimeCounter;

	// insert this at the end of the queue
	insque((struct qelem *)&newEntry, (struct qelem *)meshHead.q_back);
	nMeshEntries++;
}

// find a callsign in the list
struct mesh_entry_t *findCall(uint32_t call)
{
	struct mesh_entry_t *elem = &meshHead;

	do {
		if(elem->encCall == call)
			return elem;
		elem = elem->q_forw;
	} while(elem != NULL);

	return NULL;
}

// list the mesh status: walk the mesh entries
void Mesh_ListStatus(void)
{
	USART_Print_string("Stations Heard: %d\r\n", nMeshEntries);
	if(nMeshEntries == 0)
		return;

	// process the list
}
