/*---------------------------------------------------------------------------
	Project:	      WL33_NUCLEO_UART

	File Name:	      setup.h

	Author:		      MartinA

	Creation Date:	  Jan 13, 2025

	Description:	  Definitions for setup data

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

				  Copyright (c) 2024-25 Alberta Digital Radio Communications Society

	Revision History:

---------------------------------------------------------------------------*/
#ifndef INC_SETUP_H_
#define INC_SETUP_H_

#include <stm32wl3x_hal_mrsubg.h>

#include "frame.h"
#include "usart.h"

// defined elsewhere
extern SMRSubGConfig MRSUBG_RadioInitStruct;

typedef struct setup_flags_t {
	unsigned	fsk:	1;			// can run FSK
	unsigned	ofdm:	1;			// can run OFDM
	unsigned 	aredn:	1;			// is an AREDN node
	unsigned	repeat:	1;			// repeat mode default
	unsigned	ext:	1;			// use extended callsign
	unsigned	unused: 3;			// unused
} SETUP_FLAGS;

// setup data struct
typedef struct setup_data_t {
	SETUP_FLAGS		flags;					// flags
	char			stnCall[MAX_CALL];		// station call sign
	char			extCall[EXT_CALL];		// extended call sign
	char			latitude[10];			// latititude
	char			longitude[10];			// longitude
	char			gridSq[10];				// grid square
	SMRSubGConfig	*radioConfig;			// radio configuration
} SETUP_DATA;

// links in
void printSetupStruct(void);				// print setup struct
char *GetMyCall(void);						// return the station's callsign
int SetupBeacon(void *f);					// setup beacon payload

#endif /* INC_SETUP_H_ */
