/*---------------------------------------------------------------------------
	Project:	      WL33_NUCLEO_UART

	File Name:	      tasks.h

	Author:		      MartinA

	Creation Date:	  Jan 12, 2025

	Description:	  Declarations and entry points for system tasks

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

				  Copyright (c) 2024-25 Alberta Digital Radio Communications Society

	Revision History:

---------------------------------------------------------------------------*/

#ifndef INC_TASKS_H_
#define INC_TASKS_H_

// real time task defines
#define	MAIN_TASK_SCHED			100				// 100 ms main task scheduling
#define	TX_TASK_SCHED			10				// tx task
#define RX_TASK_SCHED			10				// rx task

// usart task
void USART_API_init(void);

// menu (main) task
void Menu_Task_Init(void);
void Menu_Task_Exec(void);

// Frame Task
void Frame_task_init(void);
void Frame_Txtask_exec(void);
void Frame_Rxtask_exec(void);

// Mesh Task
void Mesh_Task_Init(void);
void Mesh_ProcessBeacon(void *frame);
void Mesh_ListStatus(void);

// chat task
void Chat_Task_init(void);
void Chat_Task_welcome(void);
uint8_t Chat_Task_exec(void);

// beacon task
void Beacon_Task_init(void);
void Beacon_Task_exec(void);

#endif /* INC_TASKS_H_ */
