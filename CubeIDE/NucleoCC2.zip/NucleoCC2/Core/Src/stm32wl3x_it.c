/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32wl3x_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32wl3x_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern DMA_HandleTypeDef hdma_lpuart1_rx;
extern DMA_HandleTypeDef hdma_lpuart1_tx;
extern DMA_HandleTypeDef hdma_usart1_tx;
extern DMA_HandleTypeDef hdma_usart1_rx;
extern UART_HandleTypeDef hlpuart1;
extern UART_HandleTypeDef huart1;
extern RTC_HandleTypeDef hrtc;
extern DMA_HandleTypeDef hdma_spi1_rx;
extern DMA_HandleTypeDef hdma_spi1_tx;
extern SPI_HandleTypeDef hspi1;
extern TIM_HandleTypeDef htim2;

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/******************************************************************************/
/* STM32WL3x Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32wl3x.s).                    */
/******************************************************************************/

/**
  * @brief This function handles SPI1 interrupt.
  */
void SPI1_IRQHandler(void)
{
  /* USER CODE BEGIN SPI1_IRQn 0 */

  /* USER CODE END SPI1_IRQn 0 */
  HAL_SPI_IRQHandler(&hspi1);
  /* USER CODE BEGIN SPI1_IRQn 1 */

  /* USER CODE END SPI1_IRQn 1 */
}

/**
  * @brief This function handles USART1 Interrupt.
  */
void USART1_IRQHandler(void)
{
  /* USER CODE BEGIN USART1_IRQn 0 */

  /* USER CODE END USART1_IRQn 0 */
  HAL_UART_IRQHandler(&huart1);
  /* USER CODE BEGIN USART1_IRQn 1 */

  /* USER CODE END USART1_IRQn 1 */
}

/**
  * @brief This function handles LPUART1 Interrupt.
  */
void LPUART1_IRQHandler(void)
{
  /* USER CODE BEGIN LPUART1_IRQn 0 */

  /* USER CODE END LPUART1_IRQn 0 */
  HAL_UART_IRQHandler(&hlpuart1);
  /* USER CODE BEGIN LPUART1_IRQn 1 */

  /* USER CODE END LPUART1_IRQn 1 */
}

/**
  * @brief This function handles TIM2 global interrupt.
  */
void TIM2_IRQHandler(void)
{
  /* USER CODE BEGIN TIM2_IRQn 0 */

  /* USER CODE END TIM2_IRQn 0 */
  HAL_TIM_IRQHandler(&htim2);
  /* USER CODE BEGIN TIM2_IRQn 1 */

  /* USER CODE END TIM2_IRQn 1 */
}

/**
  * @brief This function handles RTC interrupt.
  */
void RTC_IRQHandler(void)
{
  /* USER CODE BEGIN RTC_IRQn 0 */

  /* USER CODE END RTC_IRQn 0 */
  HAL_RTC_AlarmIRQHandler(&hrtc);
  HAL_RTCEx_WakeUpTimerIRQHandler(&hrtc);
  /* USER CODE BEGIN RTC_IRQn 1 */

  /* USER CODE END RTC_IRQn 1 */
}

/**
  * @brief This function handles GPIOA interrupt.
  */
void GPIOA_IRQHandler(void)
{
  /* USER CODE BEGIN GPIOA_IRQn 0 */

  /* USER CODE END GPIOA_IRQn 0 */
  BSP_PB_IRQHandler(GPIOA,B2);
  BSP_PB_IRQHandler(GPIOA,B1);
  /* USER CODE BEGIN GPIOA_IRQn 1 */

  /* USER CODE END GPIOA_IRQn 1 */
}

/**
  * @brief This function handles GPIOB interrupt.
  */
void GPIOB_IRQHandler(void)
{
  /* USER CODE BEGIN GPIOB_IRQn 0 */

  /* USER CODE END GPIOB_IRQn 0 */
  BSP_PB_IRQHandler(GPIOB,B3);
  /* USER CODE BEGIN GPIOB_IRQn 1 */

  /* USER CODE END GPIOB_IRQn 1 */
}

/**
  * @brief This function handles DMA global interrupt.
  */
void DMA_IRQHandler(void)
{
  /* USER CODE BEGIN DMA_IRQn 0 */

  /* USER CODE END DMA_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_usart1_tx);
  HAL_DMA_IRQHandler(&hdma_spi1_rx);
  HAL_DMA_IRQHandler(&hdma_spi1_tx);
  HAL_DMA_IRQHandler(&hdma_usart1_rx);
  HAL_DMA_IRQHandler(&hdma_lpuart1_rx);
  HAL_DMA_IRQHandler(&hdma_lpuart1_tx);
  /* USER CODE BEGIN DMA_IRQn 1 */

  /* USER CODE END DMA_IRQn 1 */
}

/**
  * @brief This function handles MRSUBG Busy interrupt.
  */
void MRSUBG_BUSY_IRQHandler(void)
{
  /* USER CODE BEGIN MRSUBG_BUSY_IRQn 0 */

  /* USER CODE END MRSUBG_BUSY_IRQn 0 */
  HAL_MRSubG_BUSY_IRQHandler();
  /* USER CODE BEGIN MRSUBG_BUSY_IRQn 1 */

  /* USER CODE END MRSUBG_BUSY_IRQn 1 */
}

/**
  * @brief This function handles MRSUBG interrupt.
  */
void MRSUBG_IRQHandler(void)
{
  /* USER CODE BEGIN MRSUBG_IRQn 0 */

  /* USER CODE END MRSUBG_IRQn 0 */
  HAL_MRSubG_IRQHandler();
  /* USER CODE BEGIN MRSUBG_IRQn 1 */

  /* USER CODE END MRSUBG_IRQn 1 */
}

/**
  * @brief This function handles MRSUBG TX/RX Sequence interrupt.
  */
void MRSUBG_TX_RX_SEQUENCE_IRQHandler(void)
{
  /* USER CODE BEGIN MRSUBG_TX_RX_SEQUENCE_IRQn 0 */

  /* USER CODE END MRSUBG_TX_RX_SEQUENCE_IRQn 0 */
  HAL_MRSubG_TX_RX_SEQUENCE_IRQHandler();
  /* USER CODE BEGIN MRSUBG_TX_RX_SEQUENCE_IRQn 1 */

  /* USER CODE END MRSUBG_TX_RX_SEQUENCE_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
